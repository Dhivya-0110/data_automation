import sqlite3
import pandas as pd
import os

def store_data():
    #define file paths
    csv_path = "stock_data/aapl_stock.csv"
    db_path = "stock_data/stock_data.db"

    #check if csv file exists
    if not os.path.exists(csv_path):
      print("CSV file not found")
      exit()

    #load csv data into a dataframe
    df = pd.read_csv(csv_path)

    #connect to the SQLite database (it will create the file if it doesn't exist)
    conn = sqlite3.connect(db_path)

    #save dataframe to SQL table
    df.to_sql("stocks", conn, if_exists="replace", index=False)

    #close the database connection 
    conn.close()

    print(f"data saved sucessfully at '{db_path}'")