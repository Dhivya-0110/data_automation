import schedule
import time
from fetch_data import fetch_data  # Import API function
from clean_data import clean_data  # Import data cleaning function
from store_data import store_data  # Import database function

def job():
    print("Fetching new stock data...")
    fetch_data() 
    print("Data fetched successfully!")

    print("Cleaning the data...")
    clean_data() 
    print("Data cleaned successfully!")

    print("Storing data in the database...")
    store_data()
    print("Database updated successfully!")

# Schedule the job to run every hour
schedule.every().hour.do(job)

print("Auto-update script started... Fetching data every hour.")

# Keep running the script continuously
while True:
    schedule.run_pending()  
    time.sleep(60)  
