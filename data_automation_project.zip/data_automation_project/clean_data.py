import json
import os
import pandas as pd

def clean_data():
    #Define file paths
    json_path = "stock_data/aapl_stock.json"
    csv_path = "stock_data/aapl_stock.csv"

    #check if the json file exists
    if not os.path.exists(json_path):
      print("json file not found !")
      exit()

    #load json file 
    with open(json_path, "r") as file:
      data = json.load(file)

    #Extract time series data    
    if "Time Series (5min)" in data:
      time_series = data["Time Series (5min)"]

      # Convert JSON to DataFrame
      df = pd.DataFrame.from_dict(time_series, orient="index")
      df.columns = ["Open", "High", "Low", "Close", "Volume"]

      # Reset index and rename columns
      df.reset_index(inplace=True)
      df.rename(columns={"index": "Timestamp"}, inplace=True)

      # Save to CSV
      df.to_csv(csv_path, index=False)
      print(f"📂 Cleaned data saved successfully as '{csv_path}'")

      # Print first 5 rows
      print("✅ Cleaned Data (First 5 Rows):")
      print(df.head())
    else:
       print("❌ Error: 'Time Series (5min)' not found in the JSON file.")