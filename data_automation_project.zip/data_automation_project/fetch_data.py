import requests
import json

def fetch_data():
    API_KEY = "GSXZ3OK8EDOBLX6V" #API key
    BASE_URL = "https://www.alphavantage.co/query"

    params = {
        "function": "TIME_SERIES_INTRADAY",
        "symbol" : "AAPL", #Apple stock
        "interval" : "5min",
        "apikey": API_KEY
    }

    response = requests.get(BASE_URL, params=params)
    data = response.json()

    print(f"Status Code: {response.status_code}")


    if response.status_code == 200:
       data = response.json()
       #save the JSON data to a file
       with open("stock_data/aapl_stock.json", "w") as file: #create folder "stock_data"
         json.dump(data, file, indent=4) #save with indentation
         print("data saved sucessfully!")  # Print the JSON response
    else:
         print("Error fetching data. Please check your API key or internet connection.")